DRIP NATION WEBSITE — UPDATED TEACHING GUIDE

CONTENTS
- index.html: full website code in one HTML file, including CSS design and all product sections.
- drip-nation-banner.png: homepage banner.
- drip-nation-tshirt.png: T-shirt image.
- drip-nation-tracksuit-top.png: new tracksuit top design.
- drip-nation-tracksuit-pants.png: new tracksuit pants design.
- drip-nation-cap.png: cap image.

IMPORTANT
The website code is in one HTML file, but keep all PNG image files in the same folder as index.html.

TO UPDATE YOUR LIVE GITHUB WEBSITE
1. Open your repository: thabiso1608-png/drip-nation-.
2. Upload the new index.html and these two new images:
   - drip-nation-tracksuit-top.png
   - drip-nation-tracksuit-pants.png
3. Also keep the existing banner, T-shirt and cap image files in the repository.
4. If GitHub asks whether to replace index.html, confirm that you want to replace it.
5. Commit the changes to the main branch.
6. Wait a few minutes, then refresh your website.

TEACHING BASICS
- HTML provides the page structure.
- CSS inside <style> controls colours, layout, spacing and mobile display.
- Each <img src="filename.png"> loads an image from the same folder.
- Product names and example prices are written in the product cards.
- This is a product showcase only; it does not process payments or store orders.
